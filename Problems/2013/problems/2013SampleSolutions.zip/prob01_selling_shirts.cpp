
#include <string>
#include <iostream>
#include <vector>
#include <math.h>

using namespace std;

int main( int argc, char* argv[] )
{
   int N;
   // read the number of shirts from the input stream
   cin >> N;
   int P = 8 * N - 95;
   cout << P << endl;
}

