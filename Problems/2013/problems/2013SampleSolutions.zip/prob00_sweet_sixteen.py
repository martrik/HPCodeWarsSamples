#!/usr/bin/env python
'''
CodeWars 2013

'''
import sys

print ("16 Great Years of CodeWars!")
